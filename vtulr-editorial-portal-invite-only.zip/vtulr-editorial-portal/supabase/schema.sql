-- Run this entire file in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'writer' check (role in ('eic','managing_editor','research_editor','copy_editor','layout_editor','writer')),
  approved boolean not null default true,
  created_at timestamptz default now()
);

-- Invited accounts receive their approved role only when they accept the EIC invitation.
create or replace function public.handle_new_invited_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, role, approved)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'invited_role', 'writer'),
    true
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_invited on auth.users;
create trigger on_auth_user_invited
after insert on auth.users
for each row execute procedure public.handle_new_invited_user();
create table if not exists public.articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  writer_name text,
  research_editor_name text,
  copy_editor_name text,
  layout_editor_name text,
  due_date date,
  stage text default 'Topic approval',
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);
create table if not exists public.article_tasks (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  role text not null,
  label text not null,
  completed boolean default false,
  completed_by uuid references auth.users(id),
  completed_at timestamptz,
  created_at timestamptz default now()
);
create table if not exists public.issues (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  role text not null,
  category text not null,
  location text,
  original_text text,
  issue text not null,
  recommendation text,
  source_url text,
  priority text default 'Moderate',
  status text default 'Unresolved',
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);
create table if not exists public.article_assets (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  kind text not null,
  file_name text not null,
  storage_path text not null,
  public_url text,
  uploaded_by uuid references auth.users(id),
  created_at timestamptz default now()
);
alter table public.profiles enable row level security;
alter table public.articles enable row level security;
alter table public.article_tasks enable row level security;
alter table public.issues enable row level security;
alter table public.article_assets enable row level security;

-- Initial version: authenticated VTULR users can read shared workspace data.
-- Restrict writes by role and article assignment before using with sensitive/private material.
create policy "authenticated profiles read" on public.profiles for select to authenticated using (true);
create policy "users create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
-- Profile roles are not user-editable. EIC role changes should be performed by a protected admin workflow.
create policy "authenticated articles read" on public.articles for select to authenticated using (true);
create policy "authenticated articles insert" on public.articles for insert to authenticated with check (auth.uid() = created_by);
create policy "authenticated articles update" on public.articles for update to authenticated using (true);
create policy "authenticated tasks read" on public.article_tasks for select to authenticated using (true);
create policy "authenticated tasks insert" on public.article_tasks for insert to authenticated with check (true);
create policy "authenticated tasks update" on public.article_tasks for update to authenticated using (true);
create policy "authenticated issues read" on public.issues for select to authenticated using (true);
create policy "authenticated issues insert" on public.issues for insert to authenticated with check (auth.uid() = created_by);
create policy "authenticated issues update" on public.issues for update to authenticated using (true);
create policy "authenticated assets read" on public.article_assets for select to authenticated using (true);
create policy "authenticated assets insert" on public.article_assets for insert to authenticated with check (auth.uid() = uploaded_by);

-- Create a public bucket for article images, then restrict it to authenticated users in Storage settings.
insert into storage.buckets (id,name,public) values ('article-assets','article-assets',true)
on conflict (id) do nothing;
create policy "authenticated upload article assets" on storage.objects for insert to authenticated
with check (bucket_id = 'article-assets');
create policy "public read article assets" on storage.objects for select to public
using (bucket_id = 'article-assets');

-- FIRST EIC SETUP:
-- 1. Temporarily create the EIC account from Supabase Authentication > Users > Add user.
-- 2. Copy the user's UUID, then run:
-- insert into public.profiles (id, full_name, role, approved)
-- values ('PASTE-USER-UUID-HERE', 'EIC NAME', 'eic', true)
-- on conflict (id) do update set full_name=excluded.full_name, role='eic', approved=true;
--
-- All subsequent members must be invited by the EIC from the app.
-- Disable public sign-ups in Supabase Authentication > Settings > User Signups.

