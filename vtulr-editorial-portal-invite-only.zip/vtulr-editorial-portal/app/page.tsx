 "use client";
import { useEffect, useState } from "react";
import { supabase, ROLE_LABELS, TASKS } from "../lib/supabase";

type Profile = { id:string; full_name:string; role:keyof typeof ROLE_LABELS };
type Article = { id:string; title:string; writer_name:string; research_editor_name:string; copy_editor_name:string; layout_editor_name:string; due_date:string|null; stage:string };
type Issue = { id:string; article_id:string; role:string; category:string; location:string; original_text:string; issue:string; recommendation:string; source_url:string; priority:string; status:string; created_at:string };

const blankForm = {title:"", writer_name:"", research_editor_name:"", copy_editor_name:"", layout_editor_name:"", due_date:""};
export default function Home() {
  const [session,setSession] = useState<any>(null);
  const [profile,setProfile] = useState<Profile|null>(null);
  const [articles,setArticles] = useState<Article[]>([]);
  const [selected,setSelected] = useState<Article|null>(null);
  const [tasks,setTasks] = useState<any[]>([]);
  const [issues,setIssues] = useState<Issue[]>([]);
  const [form,setForm] = useState(blankForm);
  const [auth,setAuth] = useState({email:"",password:""});
  const [inviteOpen,setInviteOpen] = useState(false);
  const [invite,setInvite] = useState({email:"",full_name:"",role:"writer"});
  const [inviteBusy,setInviteBusy] = useState(false);
  const [notice,setNotice] = useState("");
  const [newIssue,setNewIssue] = useState({category:"Source verification",location:"",original_text:"",issue:"",recommendation:"",source_url:"",priority:"Moderate"});
  const [showAdd,setShowAdd] = useState(false);
  const [showIssue,setShowIssue] = useState(false);
  const [uploading,setUploading] = useState(false);

  useEffect(()=>{supabase.auth.getSession().then(({data})=>{setSession(data.session); if(data.session) load(data.session.user.id);});
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>{setSession(s); if(s) load(s.user.id); else {setProfile(null);setArticles([]);}});
    return ()=>subscription.unsubscribe();
  },[]);
  async function load(uid:string){
    const {data:p}=await supabase.from("profiles").select("*").eq("id",uid).single();
    if(p) setProfile(p);
    const {data:a}=await supabase.from("articles").select("*").order("created_at",{ascending:false});
    setArticles(a||[]);
  }
  async function refreshArticle(a:Article){
    setSelected(a);
    const {data:t}=await supabase.from("article_tasks").select("*").eq("article_id",a.id).order("created_at");
    const {data:i}=await supabase.from("issues").select("*").eq("article_id",a.id).order("created_at",{ascending:false});
    setTasks(t||[]); setIssues(i||[]);
  }
  async function signIn(e:any){
    e.preventDefault();
    const {error}=await supabase.auth.signInWithPassword({email:auth.email,password:auth.password});
    setNotice(error?.message||"Signed in.");
  }
  async function sendInvite(e:any){
    e.preventDefault();setInviteBusy(true);
    try {
      const {data:{session:current}}=await supabase.auth.getSession();
      const response=await fetch("/api/invite",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${current?.access_token||""}`},body:JSON.stringify(invite)});
      const result=await response.json();
      setNotice(result.error||"Invitation sent. The member can accept it by email.");
      if(response.ok){setInviteOpen(false);setInvite({email:"",full_name:"",role:"writer"});}
    } catch {setNotice("Could not send invitation. Please try again.");}
    finally {setInviteBusy(false);}
  }
  async function addArticle(e:any){e.preventDefault(); const {data,error}=await supabase.from("articles").insert({...form,created_by:session.user.id,stage:"Topic approval"}).select().single();
    if(error){setNotice(error.message);return;}
    const batch:any[]=[];
    (Object.entries(TASKS) as [string,string[]][]).forEach(([role,list])=>list.forEach(label=>batch.push({article_id:data.id,role,label,completed:false})));
    const {error:taskError}=await supabase.from("article_tasks").insert(batch);
    setNotice(taskError?taskError.message:"Article created."); setShowAdd(false);setForm(blankForm);await load(session.user.id);refreshArticle(data);}
  async function toggleTask(task:any){const {error}=await supabase.from("article_tasks").update({completed:!task.completed,completed_by:!task.completed?session.user.id:null,completed_at:!task.completed?new Date().toISOString():null}).eq("id",task.id);
    if(!error)setTasks(old=>old.map(t=>t.id===task.id?{...t,completed:!t.completed}:t));}
  async function submitIssue(e:any){e.preventDefault();const {error}=await supabase.from("issues").insert({...newIssue,article_id:selected!.id,role:profile!.role,created_by:session.user.id,status:"Unresolved"});
    setNotice(error?.message||"Issue submitted.");setShowIssue(false);setNewIssue({category:"Source verification",location:"",original_text:"",issue:"",recommendation:"",source_url:"",priority:"Moderate"});if(selected)refreshArticle(selected);}
  async function uploadImage(file:File){if(!selected)return;setUploading(true);const path=`${selected.id}/${Date.now()}-${file.name}`;const {data,error}=await supabase.storage.from("article-assets").upload(path,file,{upsert:true});
    if(error){setNotice(error.message);setUploading(false);return;}
    const {data:pub}=supabase.storage.from("article-assets").getPublicUrl(path);
    const {error:dbErr}=await supabase.from("article_assets").insert({article_id:selected.id,kind:"Article image",file_name:file.name,storage_path:path,public_url:pub.publicUrl,uploaded_by:session.user.id});
    setNotice(dbErr?.message||"Article image uploaded.");setUploading(false);
    const {error:taskErr}=await supabase.from("article_tasks").update({completed:true,completed_by:session.user.id,completed_at:new Date().toISOString()}).eq("article_id",selected.id).eq("role","layout").eq("label","Article image uploaded");
    const {data:t}=await supabase.from("article_tasks").select("*").eq("article_id",selected.id).order("created_at");setTasks(t||[]);
  }
  async function resolveIssue(issue:Issue){const {error}=await supabase.from("issues").update({status:"Resolved"}).eq("id",issue.id);if(!error)setIssues(old=>old.map(x=>x.id===issue.id?{...x,status:"Resolved"}:x));}
  async function signOut(){await supabase.auth.signOut();setSelected(null);}
  const role = profile?.role;
  const canManage = role==="eic"||role==="managing_editor";
  const visibleArticles = canManage?articles:articles.filter(a=>{
    if(role==="writer")return a.writer_name===profile?.full_name;
    if(role==="research_editor")return a.research_editor_name===profile?.full_name;
    if(role==="copy_editor")return a.copy_editor_name===profile?.full_name;
    if(role==="layout_editor")return a.layout_editor_name===profile?.full_name;
    return false;
  });
  const roleTasks = role==="research_editor"?"research":role==="copy_editor"?"copy":role==="layout_editor"?"layout":role==="writer"?"writer":null;
  const progress = tasks.length?Math.round(tasks.filter(t=>t.completed).length/tasks.length*100):0;

  if(!session)return <main className="authWrap"><section className="brand"><div className="seal">VT</div><p className="eyebrow">VIRGINIA TECH UNDERGRADUATE LAW REVIEW</p><h1>Editorial Portal</h1><p>A shared workspace for articles, editorial reviews, submissions, and publication.</p></section><form className="auth card" onSubmit={signIn}><h2>Member login</h2><p className="muted">VTULR accounts are invitation-only. Ask the Editor-in-Chief for an invitation.</p><label>Email<input type="email" required value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})}/></label><label>Password<input type="password" required minLength={6} value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})}/></label><button className="primary">Log in</button><p className="muted">{notice}</p></form></main>;

  if(!profile?.role || !(["eic","managing_editor","research_editor","copy_editor","layout_editor","writer"] as string[]).includes(profile.role))return <main className="authWrap"><section className="card"><h2>Account awaiting role assignment</h2><p>Your account exists, but an administrator must assign your VTULR role and add your name to the profiles table.</p><button className="secondary" onClick={signOut}>Log out</button></section></main>;

  return <main className="shell">
    <aside className="sidebar"><div className="brandMini"><div className="seal small">VT</div><div><b>VTULR</b><small>EDITORIAL PORTAL</small></div></div><nav><span className="navLabel">WORKSPACE</span><button className={!selected?"nav active":"nav"} onClick={()=>setSelected(null)}>▦ &nbsp; My dashboard</button><span className="navLabel">ACCOUNT</span><div className="userBox"><b>{profile.full_name}</b><small>{ROLE_LABELS[role!]}</small></div><button className="nav" onClick={signOut}>↪ &nbsp; Log out</button></nav><div className="sidebarFoot">Virginia Tech Undergraduate<br/>Law Review</div></aside>
    <section className="content">
      <header className="topbar"><div><p className="eyebrow">VTULR / WORKSPACE</p><h1>{selected?selected.title:"My dashboard"}</h1></div>{canManage&&<div className="headerActions">{role==="eic"&&<button className="secondary" onClick={()=>setInviteOpen(true)}>＋ Invite member</button>}<button className="primary" onClick={()=>setShowAdd(true)}>＋ Add article</button></div>}</header>
      {notice&&<div className="notice" onClick={()=>setNotice("")}>{notice} <span>×</span></div>}
      {!selected?<><div className="stats"><div className="stat card"><small>Visible articles</small><strong>{visibleArticles.length}</strong></div><div className="stat card"><small>Open assignments</small><strong>{visibleArticles.reduce((n,a)=>n,0)}</strong></div><div className="stat card"><small>Role</small><strong className="roleStat">{ROLE_LABELS[role!]}</strong></div></div><div className="sectionHead"><div><h2>{canManage?"All articles":"My assigned articles"}</h2><p className="muted">Open an article to view tasks, submit work, and track revisions.</p></div></div>{visibleArticles.length===0?<div className="empty card"><h3>No articles assigned yet</h3><p>When an article is assigned to you, it will appear here.</p></div>:<div className="articleList">{visibleArticles.map(a=><button className="articleRow card" key={a.id} onClick={()=>refreshArticle(a)}><div><b>{a.title}</b><small>Writer: {a.writer_name||"Unassigned"} · Due: {a.due_date||"Not set"}</small></div><span className="stage">{a.stage}</span><span>→</span></button>)}</div>}</>
      :<><button className="back" onClick={()=>setSelected(null)}>← Back to dashboard</button><div className="articleMeta card"><div><small>WRITER</small><b>{selected.writer_name||"Unassigned"}</b></div><div><small>RESEARCH EDITOR</small><b>{selected.research_editor_name||"Unassigned"}</b></div><div><small>COPY EDITOR</small><b>{selected.copy_editor_name||"Unassigned"}</b></div><div><small>LAYOUT EDITOR</small><b>{selected.layout_editor_name||"Unassigned"}</b></div><div><small>FINAL DEADLINE</small><b>{selected.due_date||"Not set"}</b></div></div>
        <div className="progress card"><div className="between"><b>Article task completion</b><b>{progress}%</b></div><div className="bar"><i style={{width:progress+"%"}}/></div></div>
        {(["research","copy","writer","layout"] as const).filter(r=>canManage||r===roleTasks).map(r=><section className="panel card" key={r}><div className="between"><div><p className="eyebrow">{r.toUpperCase()} SUBMISSION</p><h2>{r==="research"?"Research editor checklist":r==="copy"?"Copy editor checklist":r==="writer"?"Writer revision checklist":"Layout editor checklist"}</h2></div><span className="pill">{tasks.filter(t=>t.role===r&&t.completed).length}/{tasks.filter(t=>t.role===r).length} complete</span></div><div className="checkList">{tasks.filter(t=>t.role===r).map(t=><label className="check" key={t.id}><input type="checkbox" checked={t.completed} onChange={()=>toggleTask(t)}/><span>{t.label}</span></label>)}</div>
          {r==="research"&&<div className="formCallout"><div><b>Source & citation verification form</b><p>Record each source, authority, citation, or factual issue that needs attention.</p></div><button className="secondary" onClick={()=>setShowIssue(true)}>＋ Submit research issue</button></div>}
          {r==="copy"&&<div className="formCallout"><div><b>Copy editing submission</b><p>Submit an editorial note or identify a passage that needs revision.</p></div><button className="secondary" onClick={()=>{setNewIssue({...newIssue,category:"Copy editing"});setShowIssue(true)}}>＋ Submit copy edit note</button></div>}
          {r==="layout"&&<div className="uploadBox"><b>Article image upload</b><p>Upload the image intended to accompany this article. The upload will be stored with the article.</p><input type="file" accept="image/*" onChange={e=>e.target.files?.[0]&&uploadImage(e.target.files[0])}/>{uploading&&<small>Uploading…</small>}<small>Uploading an image also checks off the “Article image uploaded” task.</small></div>}
          {r==="writer"&&<div className="formCallout"><div><b>Writer revision submission</b><p>Use the issue list below to respond to editor feedback and submit revised work.</p></div><button className="secondary" onClick={()=>{setNewIssue({...newIssue,category:"Writer response"});setShowIssue(true)}}>＋ Submit writer response</button></div>}
        </section>)}
        <section className="panel card"><div className="between"><div><p className="eyebrow">EDITORIAL FEEDBACK</p><h2>Issues & submissions</h2></div><span className="pill">{issues.length} entries</span></div>{issues.length===0?<p className="muted">No issues or submissions yet.</p>:issues.map(i=><div className="issue" key={i.id}><div className="between"><b>{i.category}</b><span className={i.status==="Resolved"?"resolved":"unresolved"}>{i.status}</span></div><small>{i.location||"Location not specified"} · {i.priority} priority</small>{i.original_text&&<blockquote>{i.original_text}</blockquote>}<p>{i.issue}</p>{i.recommendation&&<p><b>Suggested action:</b> {i.recommendation}</p>}{i.source_url&&<a href={i.source_url} target="_blank">Supporting source ↗</a>}{canManage&&i.status!=="Resolved"&&<button className="link" onClick={()=>resolveIssue(i)}>Mark resolved</button>}</div>)}</section>
      </>}
    </section>
    {inviteOpen&&<div className="modalShade"><form className="modal card" onSubmit={sendInvite}><div className="between"><h2>Invite a VTULR member</h2><button type="button" className="link" onClick={()=>setInviteOpen(false)}>×</button></div><p className="muted">Only the EIC can invite members. The person will receive an email invitation to create their account.</p><label>Full name<input required value={invite.full_name} onChange={e=>setInvite({...invite,full_name:e.target.value})}/></label><label>Email address<input type="email" required value={invite.email} onChange={e=>setInvite({...invite,email:e.target.value})}/></label><label>VTULR role<select value={invite.role} onChange={e=>setInvite({...invite,role:e.target.value})}><option value="managing_editor">Managing Editor</option><option value="research_editor">Research Editor</option><option value="copy_editor">Copy Editor</option><option value="layout_editor">Layout Editor</option><option value="writer">Staff Writer</option></select></label><button className="primary" disabled={inviteBusy}>{inviteBusy?"Sending invitation…":"Send invitation"}</button></form></div>}
    {showAdd&&<div className="modalShade"><form className="modal card" onSubmit={addArticle}><div className="between"><h2>Add an article</h2><button type="button" className="link" onClick={()=>setShowAdd(false)}>×</button></div><p className="muted">Create an article and assign its editorial team.</p>{Object.entries({title:"Article title",writer_name:"Writer name",research_editor_name:"Research editor",copy_editor_name:"Copy editor",layout_editor_name:"Layout editor",due_date:"Final deadline"}).map(([k,label])=><label key={k}>{label}<input required={k==="title"} type={k==="due_date"?"date":"text"} value={(form as any)[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/></label>)}<button className="primary">Create article tracker</button></form></div>}
    {showIssue&&<div className="modalShade"><form className="modal card" onSubmit={submitIssue}><div className="between"><h2>Submit a form</h2><button type="button" className="link" onClick={()=>setShowIssue(false)}>×</button></div><p className="muted">Record an issue, editorial note, or writer response.</p><label>Form type<select value={newIssue.category} onChange={e=>setNewIssue({...newIssue,category:e.target.value})}>{["Source verification","Legal authority","Citation verification","Unsupported claim","Research gap","Copy editing","Writer response","Other"].map(x=><option>{x}</option>)}</select></label><label>Location in article<input placeholder="Page, paragraph, sentence, or footnote" value={newIssue.location} onChange={e=>setNewIssue({...newIssue,location:e.target.value})}/></label><label>Original text or citation<textarea value={newIssue.original_text} onChange={e=>setNewIssue({...newIssue,original_text:e.target.value})}/></label><label>Issue or response<textarea required value={newIssue.issue} onChange={e=>setNewIssue({...newIssue,issue:e.target.value})} placeholder="Explain what needs attention or what you changed."/></label><label>Recommended correction / action<textarea value={newIssue.recommendation} onChange={e=>setNewIssue({...newIssue,recommendation:e.target.value})}/></label><label>Source URL<input type="url" value={newIssue.source_url} onChange={e=>setNewIssue({...newIssue,source_url:e.target.value})}/></label><label>Priority<select value={newIssue.priority} onChange={e=>setNewIssue({...newIssue,priority:e.target.value})}><option>Minor</option><option>Moderate</option><option>Major</option></select></label><button className="primary">Submit</button></form></div>}
  </main>;
}