import "./globals.css";
export const metadata = { title: "VTULR Editorial Portal", description: "Virginia Tech Undergraduate Law Review editorial management" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}