import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

export async function POST(request: Request) {
  try {
    if (!serviceKey) return NextResponse.json({ error: "Server is missing SUPABASE_SERVICE_ROLE_KEY." }, { status: 500 });
    const authHeader = request.headers.get("authorization") || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return NextResponse.json({ error: "You must be logged in." }, { status: 401 });

    const publicClient = createClient(supabaseUrl, anonKey, { auth: { persistSession: false } });
    const { data: userData, error: userError } = await publicClient.auth.getUser(token);
    if (userError || !userData.user) return NextResponse.json({ error: "Invalid session." }, { status: 401 });

    const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: requester, error: profileError } = await admin
      .from("profiles").select("role, full_name").eq("id", userData.user.id).single();
    if (profileError || requester?.role !== "eic") {
      return NextResponse.json({ error: "Only the Editor-in-Chief can invite members." }, { status: 403 });
    }

    const body = await request.json();
    const email = String(body.email || "").trim().toLowerCase();
    const full_name = String(body.full_name || "").trim();
    const role = String(body.role || "");
    const allowed = ["managing_editor", "research_editor", "copy_editor", "layout_editor", "writer"];
    if (!email || !full_name || !allowed.includes(role)) {
      return NextResponse.json({ error: "Enter a name, valid email, and permitted role." }, { status: 400 });
    }

    const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
      data: { full_name, invited_role: role, invited_by: userData.user.id },
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || new URL(request.url).origin}/welcome`
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });

    // The database trigger creates the approved profile when the invite is accepted.
    return NextResponse.json({ success: true, invited_user_id: data.user?.id });
  } catch {
    return NextResponse.json({ error: "Unable to send invitation." }, { status: 500 });
  }
}
