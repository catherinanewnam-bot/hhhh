"use client";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabase";
export default function Welcome(){
 const [password,setPassword]=useState("");
 const [ready,setReady]=useState(false);
 const [notice,setNotice]=useState("Checking your invitation…");
 useEffect(()=>{let active=true; supabase.auth.getSession().then(({data})=>{if(active){setReady(!!data.session);setNotice(data.session?"Set a password for your invited account.":"Open the invitation link in your email to activate your account.");}});const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,session)=>{if(active&&session){setReady(true);setNotice("Set a password for your invited account.");}});return ()=>{active=false;subscription.unsubscribe()};},[]);
 async function submit(e:React.FormEvent){e.preventDefault();if(password.length<8){setNotice("Use at least eight characters.");return;}const {error}=await supabase.auth.updateUser({password});if(error){setNotice(error.message);return;}window.location.assign("/");}
 return <main className="authWrap"><section className="card auth"><p className="eyebrow">VTULR EDITORIAL PORTAL</p><h1>Welcome to the team</h1><p>{notice}</p>{ready&&<form onSubmit={submit}><label>Create password<input type="password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="primary">Activate my account</button></form>}</section></main>;
}
