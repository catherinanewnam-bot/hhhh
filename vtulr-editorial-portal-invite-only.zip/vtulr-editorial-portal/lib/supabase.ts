import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(url, key);

export const ROLE_LABELS = {
  eic: "Editor-in-Chief",
  managing_editor: "Managing Editor",
  research_editor: "Research Editor",
  copy_editor: "Copy Editor",
  layout_editor: "Layout Editor",
  writer: "Staff Writer"
};

export const TASKS = {
  research: [
    "Every cited source has been located and reviewed",
    "Sources are credible and appropriate for academic publication",
    "Sources support the claims they are cited for",
    "Factual claims are supported by reliable evidence",
    "Sources are sufficiently current",
    "Quotations accurately reflect the original source",
    "All cited cases have been located and reviewed",
    "Case names, citations, and stated holdings are accurate",
    "Statutes and regulations have been verified",
    "Pinpoint citations support the specific statements",
    "Missing citations and unsupported claims have been flagged",
    "Research verification form submitted"
  ],
  copy: [
    "Grammar, spelling, and punctuation reviewed",
    "Sentence structure and readability reviewed",
    "Organization and transitions reviewed",
    "Terminology is consistent",
    "Word count requirements checked",
    "Writer's responses to editorial comments reviewed",
    "Copy editing submission form completed"
  ],
  writer: [
    "Initial article submitted",
    "Research editor comments reviewed",
    "Copy editor comments reviewed",
    "Requested revisions completed",
    "Responses to editorial concerns submitted",
    "Revised article uploaded"
  ],
  layout: [
    "Correct document template used",
    "Headings and subheadings formatted",
    "Spacing, margins, and page formatting checked",
    "Footnotes and citation presentation checked",
    "Article image uploaded",
    "Image placement and caption checked",
    "Final formatting proofread completed",
    "Publication-ready document submitted"
  ]
};