# VTULR Editorial Portal

Next.js + Supabase starter for the Virginia Tech Undergraduate Law Review.

## Invitation-only access
- Public account creation is removed from the login screen.
- The EIC sees an **Invite member** action.
- The EIC can invite Managing Editors, Research Editors, Copy Editors, Layout Editors, and Staff Writers by name, email, and role.
- Invitations are sent through Supabase Auth email invitations.
- On acceptance, a database trigger creates the member profile with the invited role.
- Only the EIC can call the server-side invitation endpoint. The service-role key stays server-side.

## Included
- Email/password login
- EIC-controlled email invitations
- Role-specific article dashboards
- Create article trackers and assign role owners
- Research, copy, writer, and layout checklists
- Source/citation/revision issue forms
- Layout image upload; successful upload completes the image-upload checklist item
- Shared issue list and resolution status

## Setup

### 1. Supabase
1. Create a project at https://supabase.com.
2. Run `supabase/schema.sql` in SQL Editor.
3. In Supabase Authentication > Settings, disable public sign-ups.
4. In Project Settings > API, copy the Project URL, anon/public key, and service_role key.
5. Add the Project URL and anon key to `.env.local` as shown in `.env.example`.
6. Add `SUPABASE_SERVICE_ROLE_KEY=...` to `.env.local`. NEVER prefix this key with `NEXT_PUBLIC_` and never expose it in browser code.

### 2. Bootstrap the first EIC
1. In Supabase Authentication > Users, choose Add user and create the EIC account.
2. Copy the new user's UUID.
3. Run the EIC profile insert/update SQL at the bottom of `supabase/schema.sql`, replacing UUID and name.
4. The EIC can now log into the app and invite everyone else from the Invite member button.

### 3. Email invitations
Configure Supabase Auth email/SMTP settings so invitation emails can be delivered reliably. Set the Site URL and Redirect URLs to include `http://localhost:3000/welcome` during testing and `https://YOUR-DEPLOYMENT.vercel.app/welcome` after deployment. Invitees set their password on the welcome page.

### 4. Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000.

### 5. Deploy and share
1. Push the project to a private GitHub repository.
2. Import it into https://vercel.com.
3. Add `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SITE_URL` (your deployed URL), and `SUPABASE_SERVICE_ROLE_KEY` to Vercel Environment Variables. The service role key must be server-only.
4. Deploy. Share the Vercel URL with VTULR members.
5. Add the deployed URL to Supabase Authentication > URL Configuration > Redirect URLs.

## Security note
The invitation endpoint verifies the caller's authenticated user and checks that their database profile role is `eic` before calling Supabase Admin invite. The SQL policies are still prototype-level for collaborative shared data. Before storing unpublished submissions, add strict row-level security based on article assignments and roles, protect profile reads/updates, and implement audit logging. Do not treat the starter policies as a complete production security review.
